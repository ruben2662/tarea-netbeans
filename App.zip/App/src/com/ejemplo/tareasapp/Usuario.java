package com.ejemplo.tareasapp;

public class Usuario {
    private long id;
    private String nombre;
    private String apellido;
    private String usuario;
    private String password;

    public Usuario(long id, String nombre, String apellido, String usuario, String password) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.usuario = usuario;
        this.password = password;
    }

    public long getId() { return id; }
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getUsuario() { return usuario; }
    public String getPassword() { return password; }


}
