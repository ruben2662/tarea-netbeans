package com.ejemplo.tareasapp;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class LoginFrame extends JFrame {
    private JTextField usuarioField;
    private JPasswordField passwordField;

    public LoginFrame() {
        setTitle("Inicio de Sesion");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Usuario:"));
        usuarioField = new JTextField();
        panel.add(usuarioField);

        panel.add(new JLabel("Contraseña:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        JButton loginButton = new JButton("Iniciar Sesion");
        loginButton.addActionListener(e -> autenticarUsuario());
        panel.add(loginButton);

        add(panel);
        setVisible(true);
    }

    private void autenticarUsuario() {
        String usuario = usuarioField.getText();
        String password = new String(passwordField.getPassword());

        try (Connection conn = com.ejemplo.tareasapp.DBConnection.getConnection()) {
            String query = "SELECT * FROM usuarios WHERE usuario = ? AND password = ?";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, usuario);
                stmt.setString(2, password);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        Usuario user = new Usuario(
                                rs.getLong("id_usuario"),
                                rs.getString("nombre"),
                                rs.getString("apellido"),
                                rs.getString("usuario"),
                                rs.getString("password")
                        );
                        JOptionPane.showMessageDialog(this, "Bienvenido, " + user.getNombre());
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error de conexion: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginFrame::new);
    }
}
